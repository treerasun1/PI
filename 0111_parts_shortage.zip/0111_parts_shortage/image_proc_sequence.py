﻿# -*- coding: utf-8 -*-

"""
module :image_proc_sequence.py
CRAVIS-miniの画像処理シーケンスモジュールになります。
image_proc_component.pyに記載されている画像処理関数群を使用して、画像処理シーケンスを作成します。
単体で使用した場合、if __name__ == __main__":以下のシーケンスが実行されます。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import cv2
import numpy as np
import csv
import math
import time
import sys
import image_proc_component as ipc
import parameter_class

#############
# Function
#############

def func_image_proc_main_sequence(src_img,parameter):
    """
    画像処理シーケンス関数	
    _@param  src_img.       入力画像
    _@param  parameter.    パラメータ
    _@return ret.              各関数の戻り値（正常終了時は0）
    _@return value.           面積値[pix]
    _@return output.          結果(0：OK 1:NG)
    _@return bin_img.         2値画像.
    """
    
    ret = 0
    bin_max_val = 255
    serch_area_order = 2
    value = 0
    # 0:OK 1:NG	
    output = 0
    
    # 着目画像切り出し
    ret,roi_img = ipc.func_createRoiimg(ret,src_img,parameter.roi_x,parameter.roi_y,parameter.roi_width,parameter.roi_height)
    
    # グレースケール化
    ret,gray_img = ipc.func_grayscale(ret,roi_img)

    # メディアンフィルター
    ret,median_img = ipc.func_median_filter(ret,gray_img,parameter.median_kernel_size)
    
    # 2値化
    ret,bin_img = ipc.func_threshold(ret,median_img,parameter.bin_thr,bin_max_val)
    
    # 白黒反転
    ret,bin_not_img = ipc.func_bitwise_not(ret,bin_img)
    
    # 白画素の数カウント
    ret,value = ipc.func_countWhitePix(ret,bin_not_img)
    
    # 判定①
    if value < parameter.area_thr:
        
        # NG
        output = 1
    else:
        # OK
        output = 0
    
    return ret,value,output,bin_not_img
    
#############
# Main
#############
  
if __name__ == "__main__":
    
    ret = 0
    output = 0
    str_output = "OK"
    parameter_file_name = "parameter.ini"
    
    # パラメータファイルクラスのインスタンス化
    parameter = parameter_class.Parameter()
    # パラメータファイルの読み出し
    ret = parameter.SetParameter(parameter_file_name)
    if ret != 0:
        print "Failure Set Parameter."
        
    # 画像ファイルの読み出し
    ret,grab_img = ipc.func_imgread(ret,parameter.debug_image_file_name)
    if ret != 0:
        print "Failure Read Image."
        
    # 画像処理関数の呼出し
    ret,value,output,proc_img = func_image_proc_main_sequence(grab_img,parameter)
    
    if ret != 0:
        print "Failure Image Processing."
        output = -1
    
    # 判定
    if output == 0:
        str_output = "OK"
    
    elif output == 1:
        str_output = "NG"
    
    elif output == -1:
        str_output = "ERR"
    
    # 画像表示
    cv2.putText(grab_img,"Value:" + str(value),(10,50),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.putText(grab_img,"Output:" + str_output,(10,90),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.imshow('grab_img',np.array(grab_img,np.uint8))
    cv2.imshow('proc_img',np.array(proc_img,np.uint8))
    
    # 画像表示待機待ち
    cv2.waitKey(0)
    
    cv2.destroyAllWindows()	
