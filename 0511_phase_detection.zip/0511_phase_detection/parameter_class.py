﻿# -*- coding: utf-8 -*-

"""
module :parameter_class.py
CRAVIS-miniで設定するパラメータを一覧にしたクラスになります。
CRAVIS-miniに新しいパラメータを追加したい時に編集します。
[SystemParam]はファイルパスや各種機器のパラメータ
[ImageProcParam]は画像処理パラメータになります。
①に追加したいパラメータを記述し、
②に追加パラメータをiniファイルから読み出す内容を記述します。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import ConfigParser

class Parameter(object):
    """description of class"""
    # [SystemParam]
    # ①↓システムのパラメータはこの下に追加する.
    flag_debug_mode = 0
    flag_save_image = 0
    flag_save_output_data = 0
    flag_disp_image = 0
    light_level = 0
    shutter_speed = 0
    mcp_ether_data_length = 0
    mcp_ether_data_address = 0
    ready_io_no = 0
    ok_io_no = 0
    ng_io_no = 0
    save_image_folder_name = ""
    debug_image_file_name = ""
    debug_temp_image_file_name = ""
    inspect_output_file_name = ""

    # [ImageProcParam]
    # ①↓画像処理のパラメータはこの下に追加する.
    diminution_rate = 0
    bin_thr = 0
    resolution_theta = 0
    resolution_radius = 0
    temp_x_start = 0
    temp_y_start = 0
    temp_x_end = 0
    temp_y_end = 0
    roi_x = 0
    roi_y = 0
    roi_width = 0
    roi_height = 0
    serch_area_order = 0
    laplacian_ddepth = 0
    lap_x_start = 0
    lap_y_start = 0
    lap_x_end = 0
    lap_y_end = 0
    range = 0
    phase_width = 0
    initial_radius = 0
    final_radius = 0

    def __init__(self):
        print "Init Parameter"
    
    def SetParameter(self,file_name):
        
        """
        画像処理シーケンス関数
        _@param  self       インスタンス自身
        _@param  file_name  パラメータファイル名
        _@return ret        各関数の戻り値（正常終了時は0）
        """
        
        ret = 0
    
        try:
            inifile = ConfigParser.SafeConfigParser()
            inifile.read(file_name)
            # [SystemParam]
            # ②↓追加したパラメータはself.パラメータ名= int(inifile.get("SystemParam","パラメータ名"))の形で記述する.
            self.flag_save_image = int(inifile.get("SystemParam","flag_save_image"))
            self.flag_save_output_data = int(inifile.get("SystemParam","flag_save_output_data"))
            self.flag_disp_image = int(inifile.get("SystemParam","flag_disp_image"))
            self.light_level = int(inifile.get("SystemParam","light_level"))
            self.shutter_speed = int(inifile.get("SystemParam","shutter_speed"))
            self.mcp_ether_data_length = int(inifile.get("SystemParam","mcp_ether_data_length"))
            self.mcp_ether_data_address = int(inifile.get("SystemParam","mcp_ether_data_address"))
            self.ready_io_no = int(inifile.get("SystemParam","ready_io_no"))
            self.ok_io_no = int(inifile.get("SystemParam","ok_io_no"))
            self.ng_io_no = int(inifile.get("SystemParam","ng_io_no"))
            self.save_image_folder_name = inifile.get("SystemParam","save_image_folder_name")
            self.debug_image_file_name = inifile.get("SystemParam","debug_image_file_name")
            self.debug_temp_image_file_name = inifile.get("SystemParam","debug_temp_image_file_name")
            self.inspect_output_file_name = inifile.get("SystemParam","inspect_output_file_name")
            
            # [ImageProcParam]
            # ②↓追加したパラメータはself.パラメータ名= int(inifile.get("ImageProcParam","パラメータ名"))の形で記述する.
            self.diminution_rate = int(inifile.get("ImageProcParam","diminution_rate"))
            self.bin_thr = int(inifile.get("ImageProcParam","bin_thr"))
            self.resolution_theta = float(inifile.get("ImageProcParam","resolution_theta"))
            self.resolution_radius = float(inifile.get("ImageProcParam","resolution_radius"))
            self.temp_x_start = int(inifile.get("ImageProcParam","temp_x_start"))
            self.temp_y_start = int(inifile.get("ImageProcParam","temp_y_start"))
            self.temp_x_end = int(inifile.get("ImageProcParam","temp_x_end"))
            self.temp_y_end = int(inifile.get("ImageProcParam","temp_y_end"))
            self.roi_x = int(inifile.get("ImageProcParam","roi_x"))
            self.roi_y = int(inifile.get("ImageProcParam","roi_y"))
            self.roi_width = int(inifile.get("ImageProcParam","roi_width"))
            self.roi_height = int(inifile.get("ImageProcParam","roi_height"))
            self.serch_area_order = int(inifile.get("ImageProcParam","serch_area_order"))
            self.laplacian_ddepth = int(inifile.get("ImageProcParam","laplacian_ddepth"))
            self.lap_x_start = int(inifile.get("ImageProcParam","lap_x_start"))
            self.lap_y_start = int(inifile.get("ImageProcParam","lap_y_start"))
            self.lap_x_end = int(inifile.get("ImageProcParam","lap_x_end"))
            self.lap_y_end = int(inifile.get("ImageProcParam","lap_y_end"))
            self.range = int(inifile.get("ImageProcParam","range"))
            self.phase_width = int(inifile.get("ImageProcParam","phase_width"))
            self.initial_radius = int(inifile.get("ImageProcParam","initial_radius"))
            self.final_radius = int(inifile.get("ImageProcParam","final_radius"))


        except:
            ret = -1
            print "Failure Set Parameter."
                
        finally:
            return ret
