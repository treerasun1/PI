﻿# -*- coding: utf-8 -*-

"""
module :image_proc_sequence.py
CRAVIS-miniの画像処理シーケンスモジュールになります。
image_proc_component.pyに記載されている画像処理関数群を使用して、画像処理シーケンスを作成します。
単体で使用した場合、if __name__ == __main__":以下のシーケンスが実行されます。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import cv2
import numpy as np
import csv
import math
import time
import sys
import image_proc_component as ipc
import parameter_class

#############
# Function
#############

def func_image_proc_main_sequence(src_img,temp_img,parameter):
    """
    画像処理シーケンス関数	
    _@param  src_img.       入力画像
    _@param  parameter.    パラメータ
    _@return ret.              各関数の戻り値（正常終了時は0）
    _@return value.           面積値[pix]
    _@return output.          結果(0：OK 1:NG)
    _@return bin_img.         2値画像.
    """
    
    ret = 0
    bin_max_val = 255
    output = 0
    value = 0

    """
    テンプレート画像の作成
    """
    # グレースケール化
    ret,temp_gray_img = ipc.func_grayscale(ret,temp_img)

    
    # ブロブ画像作成
    ret,temp_roi_img,temp_remove_img = func_blob_select(ret,temp_gray_img,bin_max_val)
    
    # 円フィッティング
    ret,temp_center_x,temp_center_y,temp_radius = func_circle_fitting(ret,temp_remove_img)
   
    # 極座標展開
    ret,temp_polar_img = ipc.func_img2polar(ret,temp_gray_img,(temp_center_x,temp_center_y),parameter.range*np.pi,parameter.final_radius,parameter.initial_radius,parameter.phase_width)

    # 座標変換
    ret,temp_roi_x_start,temp_roi_y_start,temp_roi_x_end,temp_roi_y_end,temp_degree = func_point_convert(ret,parameter.temp_x_start,parameter.temp_y_start,parameter.temp_x_end,parameter.temp_y_end,temp_center_x,temp_center_y)

    # テンプレート画像作成用のポイント算出
    ret,temp_roi_x_start,temp_roi_y_start,temp_roi_width,temp_roi_height = func_temp_point(ret,temp_roi_x_start,temp_roi_y_start,temp_roi_x_end,temp_roi_y_end,parameter.initial_radius)

    # テンプレート画像の領域切り出し
    ret,temp_roi_img = ipc.func_createRoiimg(ret,temp_polar_img,temp_roi_x_start,temp_roi_y_start,temp_roi_width,temp_roi_height)

    """
    位相検出処理
    """
    # グレースケール化
    ret,src_gray_img = ipc.func_grayscale(ret,src_img)

    # ブロブ画像作成
    ret,src_roi_img,src_remove_img = func_blob_select(ret,src_gray_img,bin_max_val)
    
    # 円フィッティング
    ret,src_center_x,src_center_y,src_radius = func_circle_fitting(ret,src_remove_img)
   
    # 極座標展開
    ret,src_polar_img = ipc.func_img2polar(ret,src_gray_img,(src_center_x,src_center_y),parameter.range*np.pi,parameter.final_radius,parameter.initial_radius,parameter.phase_width)

    ## create_end_image
    ret,src_end_img = ipc.func_createRoiimg(ret,src_polar_img,0,0,temp_roi_img.shape[1],parameter.final_radius - parameter.initial_radius)

    ## conect_end_image
    ret,ext_src_polar_img = ipc.func_horizontal_conect_img(ret,src_polar_img,src_end_img)
    
    ## func_pattern_match
    ret,match_point = ipc.func_pattern_match(ret,ext_src_polar_img,temp_roi_img)
    
    #位相差計算
    value = (match_point[0] - int(temp_roi_x_start)) * parameter.resolution_theta

    return ret,value,output,ext_src_polar_img
    
    
    
def func_blob_select(ret,gray_img,bin_max_val):
    
    # 着目領域の切り取り
    ret,roi_img = ipc.func_createRoiimg(ret,gray_img,parameter.roi_x,parameter.roi_y,parameter.roi_width,parameter.roi_height)

    # 二値化
    ret,bin_img = ipc.func_threshold(ret,roi_img,parameter.bin_thr,bin_max_val)

    # ラベリング
    ret,labels,nb = ipc.func_labels(ret,bin_img)

    # ブロブ作成
    ret,areas,centroid = ipc.func_calc_feature(ret,bin_img,labels)

    # 着目ブロブの抽出
    ret,remove_img = ipc.func_blob_select(ret,areas,parameter.serch_area_order,bin_max_val,labels)    
    
    return ret,roi_img,remove_img
    
    
def func_circle_fitting(ret,src_img):
    
    # ラプラシアンフィルター
    ret,laplacian_img = ipc.func_laplacian_filter(ret,src_img,parameter.laplacian_ddepth)

    # 円フィッティング
    ret,center_x,center_y,radius = ipc.func_circle_fitting(ret,laplacian_img,parameter.lap_x_start,parameter.lap_y_start,parameter.lap_x_end,parameter.lap_y_end)
    
    center_x = center_x + parameter.roi_x
    center_y = center_y + parameter.roi_y
    
    return ret,center_x,center_y,radius
    

def func_point_convert(ret,x_start,y_start,x_end,y_end,center_x,center_y):
    
    ret,radius_start,theta_start,degree_start = ipc.func_cart2polar(ret,x_start,y_start,(center_x,center_y))
    ret,radius_end,theta_end,degree_end = ipc.func_cart2polar(ret,x_end,y_end,(center_x,center_y))

    roi_x_start = degree_start / parameter.resolution_theta
    roi_y_start = radius_start / parameter.resolution_radius

    roi_x_end = degree_end / parameter.resolution_theta
    roi_y_end = radius_end / parameter.resolution_radius

    return ret,roi_x_start,roi_y_start,roi_x_end,roi_y_end,degree_start


def func_temp_point(ret,roi_x_start,roi_y_start,roi_x_end,roi_y_end,initial_radius):
    
    roi_width = 0
    roi_height = 0
    
    if roi_x_end > roi_x_start:
        roi_width = np.int(roi_x_end - roi_x_start)
    elif roi_x_end < roi_x_start:
        roi_width = np.int(roi_x_start - roi_x_end)
        roi_x_start = roi_x_end

    if roi_y_end > roi_y_start:
        roi_height = np.int(roi_y_end - roi_y_start)
    elif roi_y_end < roi_y_start:
        roi_height = np.int(roi_y_start - roi_y_end)
        roi_y_start = roi_y_end
    
    roi_y_start = roi_y_start - initial_radius

    return ret,roi_x_start,roi_y_start,roi_width,roi_height



#############
# Main
#############
  
if __name__ == "__main__":
    
    ret = 0
    output = 0
    str_output = "OK"
    parameter_file_name = "parameter.ini"
    
    # パラメータファイルクラスのインスタンス化
    parameter = parameter_class.Parameter()
    # パラメータファイルの読み出し
    ret = parameter.SetParameter(parameter_file_name)
    if ret != 0:
        print "Failure Set Parameter."
        
    # 画像ファイルの読み出し
    ret,grab_img = ipc.func_imgread(ret,parameter.debug_image_file_name)
    if ret != 0:
        print "Failure Read SRC Image."

    # テンプレート画像ファイルの読み出し
    ret,temp_img = ipc.func_imgread(ret,parameter.debug_temp_image_file_name)
    if ret != 0:
        print "Failure Read Temp Image."

    # 画像処理関数の呼出し
    ret,value,output,proc_img = func_image_proc_main_sequence(grab_img,temp_img,parameter)
    
    if ret != 0:
        print "Failure Image Processing."
        output = -1
    
    # 判定
    if output == 0:
        str_output = "OK"
    
    elif output == 1:
        str_output = "NG"
    
    elif output == -1:
        str_output = "ERR"
    
    #描画
    cv2.putText(grab_img,"Value:" + str(value),(50,150),cv2.FONT_HERSHEY_PLAIN,10,(0,0,255),8)
    cv2.putText(grab_img,"Output:" + str_output,(50,300),cv2.FONT_HERSHEY_PLAIN,10,(0,0,255),8)

    #リサイズ
    resize_grab_img = cv2.resize(grab_img,(grab_img.shape[1]/parameter.diminution_rate,grab_img.shape[0]/parameter.diminution_rate))
    resize_proc_img = cv2.resize(proc_img,(proc_img.shape[1]/parameter.diminution_rate,proc_img.shape[0]/parameter.diminution_rate))

    # 画像表示
    cv2.imshow('grab_img',np.array(resize_grab_img,np.uint8))
    cv2.imshow('proc_img',np.array(resize_proc_img,np.uint8))
    
    # 画像表示待機待ち
    cv2.waitKey(0)
    
    cv2.destroyAllWindows()