﻿# -*- coding: utf-8 -*-

"""
module :image_proc_sequence.py
CRAVIS-miniの画像処理シーケンスモジュールになります。
image_proc_component.pyに記載されている画像処理関数群を使用して、画像処理シーケンスを作成します。
単体で使用した場合、if __name__ == __main__":以下のシーケンスが実行されます。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import cv2
import numpy as np
import csv
import math
import time
import sys
import image_proc_component as ipc
import parameter_class

#############
# Function
#############

def func_image_proc_main_sequence(src_img,parameter):
    """
    画像処理シーケンス関数	
    _@param  src_img.          入力画像
    _@param  parameter.        パラメータ
    _@return ret.              各関数の戻り値（正常終了時は0）
    _@return value.            面積値[pix]
    _@return output.           結果(0：OK 1:NG)
    _@return bin_img.          2値画像.
    """
    
    ret = 0
    bin_max_val = 255
    output = 0
    value = np.zeros((parameter.divide*2))
    gear_ok_img = []
    gear_ng_img = []
    flat_ok_img = []
    flat_ng_img = []
    gear_ok_area = []
    gear_ng_area = []
    flat_ok_area = []
    flat_ng_area = []


    # 領域切り出し
    ret,roi_img = ipc.func_createRoiimg(ret,src_img,parameter.roi_x,parameter.roi_y,parameter.roi_width,parameter.roi_height)

    # グレースケール化
    ret,gray_img = ipc.func_grayscale(ret,roi_img)

    for n in range(0,(parameter.divide*2)):
        
        center = (parameter.center_x,parameter.center_y) 
        radius_gear_min = (parameter.radius_gear_min_x,parameter.radius_gear_min_y)
        radius_gear_max = (parameter.radius_gear_max_x,parameter.radius_gear_max_y)
        radius_flat_min = radius_gear_max
        radius_flat_max = (parameter.radius_flat_max_x,parameter.radius_flat_max_y)
        
        # 分割する角度算出
        ret,start_angle = func_angle1(ret,parameter.divide,n)
        ret,end_angle = func_angle2(ret,parameter.divide,n)
        
        ## マスク処理領域作成
        # ギヤ部分
        ret,gear_mask_img = ipc.func_create_zero_img(ret,gray_img)
        ret = ipc.func_draw_ellipse(ret,gear_mask_img,center,radius_gear_max,0,start_angle,end_angle,(255,255,255),-1,8)
        ret = ipc.func_draw_ellipse(ret,gear_mask_img,center,radius_gear_min,0,start_angle,end_angle,(0, 0, 0),-1,8)
        
        # 平坦部分
        ret,flat_mask_img = ipc.func_create_zero_img(ret,gray_img)
        ret = ipc.func_draw_ellipse(ret,flat_mask_img,center,radius_flat_max,0,start_angle,end_angle,(255,255,255),-1,8)
        ret = ipc.func_draw_ellipse(ret,flat_mask_img,center,radius_flat_min,0,start_angle,end_angle,(0,0,0),-1,8)
    
        # マスク処理
        ret,gear_proc_img = ipc.func_bitwise_and(ret,gray_img,gear_mask_img)
        ret,flat_proc_img = ipc.func_bitwise_and(ret,gray_img,flat_mask_img)
    
        # 二値化
        ret,gear_cut_ok_img = ipc.func_threshold(ret,gear_proc_img,parameter.gear_ok_bin_thr,bin_max_val)
        ret,gear_cut_ng_img = ipc.func_threshold(ret,gear_proc_img,parameter.gear_ng_bin_thr,bin_max_val)
        ret,flat_cut_ok_img = ipc.func_threshold(ret,flat_proc_img,parameter.flat_ok_bin_thr,bin_max_val)
        ret,flat_cut_ng_img = ipc.func_threshold(ret,flat_proc_img,parameter.flat_ng_bin_thr,bin_max_val)
        
        # 
        gear_cut_ok_img = gear_cut_ok_img - gear_cut_ng_img
        flat_cut_ok_img = flat_cut_ok_img - flat_cut_ng_img
    
        ##AreaCount
        ret,gear_cut_ok_area = ipc.func_countWhitePix(ret,gear_cut_ok_img)
        ret,gear_cut_ng_area = ipc.func_countWhitePix(ret,gear_cut_ng_img)
        ret,flat_cut_ok_area = ipc.func_countWhitePix(ret,flat_cut_ok_img)
        ret,flat_cut_ng_area = ipc.func_countWhitePix(ret,flat_cut_ng_img)

        if ret == 0:
            ##AppendData
            gear_ok_img.append(gear_cut_ok_img)
            gear_ng_img.append(gear_cut_ng_img)
            flat_ok_img.append(flat_cut_ok_img)
            flat_ng_img.append(flat_cut_ng_img)

            gear_ok_area.append(gear_cut_ok_area)
            gear_ng_area.append(gear_cut_ng_area)
            flat_ok_area.append(flat_cut_ok_area) 
            flat_ng_area.append(flat_cut_ng_area)  

            ##Judge
            if gear_cut_ok_area < parameter.gear_ok_area_thr:
                value[n] = 1
                gear_ok_output = 1
            if gear_cut_ng_area > parameter.gear_ng_area_thr:
                value[n] = 1
                gear_ng_output = 1
            if flat_cut_ok_area < parameter.flat_ok_area_thr:
                value[n] = 1
                flat_ok_output = 1
            if flat_cut_ng_area > parameter.flat_ng_area_thr:
                value[n] = 1
                flat_ng_output = 1

    ##Judge
    if ret != 0:
        output = -1
    else:
        for n in range(0,(parameter.divide*2)):
            if value[n] != 0:
                output = 1
                break

        ###MakeImage
        for n in range(0,(parameter.divide*2)):
            gear_ok_img = gear_ok_img + gear_ok_img[n]
            gear_ng_img = gear_ng_img + gear_ng_img[n]
            flat_ok_img = flat_ok_img + flat_ok_img[n]
            flat_ng_img = flat_ng_img + flat_ng_img[n]
            
    return ret,value,output,gray_img

def func_angle1(ret,divide,func_size):

    if ret != 0:
        return ret,0

    try:
        angle1 = (360 / divide) * (func_size / 2.0)
    except:
        return -1,0

    return ret,angle1

def func_angle2(ret,divide,func_size):

    if ret != 0:
        return ret,0

    try:
        angle2 = (360 / divide) * ((func_size / 2.0) + 1)
    except:
        return -2,0

    return ret,angle2
    

#############
# Main
#############
  
if __name__ == "__main__":
    
    ret = 0
    output = 0
    str_output = "OK"
    parameter_file_name = "parameter.ini"
    
    # パラメータファイルクラスのインスタンス化
    parameter = parameter_class.Parameter()
    # パラメータファイルの読み出し
    ret = parameter.SetParameter(parameter_file_name)
    if ret != 0:
        print "Failure Set Parameter."
        
    # 画像ファイルの読み出し
    ret,grab_img = ipc.func_imgread(ret,parameter.debug_image_file_name)
    if ret != 0:
        print "Failure Read SRC Image."

    # 画像処理関数の呼出し
    ret,value,output,proc_img = func_image_proc_main_sequence(grab_img,parameter)
    
    if ret != 0:
        print "Failure Image Processing."
        output = -1
    
    # 判定
    if output == 0:
        str_output = "OK"
    
    elif output == 1:
        str_output = "NG"
    
    elif output == -1:
        str_output = "ERR"
    
    # 画像表示
    cv2.putText(grab_img,"Value:" + str(value),(10,50),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.putText(grab_img,"Output:" + str_output,(10,90),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.imshow('grab_img',np.array(grab_img,np.uint8))
    cv2.imshow('proc_img',np.array(proc_img,np.uint8))
    
    # 画像表示待機待ち
    cv2.waitKey(0)
    
    cv2.destroyAllWindows()