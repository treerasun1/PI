﻿# -*- coding: utf-8 -*-

"""
module :image_proc_sequence.py
CRAVIS-miniの画像処理シーケンスモジュールになります。
image_proc_component.pyに記載されている画像処理関数群を使用して、画像処理シーケンスを作成します。
単体で使用した場合、if __name__ == __main__":以下のシーケンスが実行されます。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import cv2
import numpy as np
import csv
import math
import time
import sys
import image_proc_component as ipc
import parameter_class

#############
# Function
#############

def func_image_proc_main_sequence(src_img,temp_img,parameter):
    """
    画像処理シーケンス関数	
    _@param  src_img.       入力画像
    _@param  parameter.    パラメータ
    _@return ret.              各関数の戻り値（正常終了時は0）
    _@return value.           面積値[pix]
    _@return output.          結果(0：OK 1:NG)
    _@return bin_img.         2値画像.
    """
    
    ret = 0
    bin_max_val = 255
    reference_position_x = 0
    reference_position_y = 0
    white_pix = 0
    value = []
    # 0:OK 1:NG
    output = 0 
    distance = "ERR"
    theta = "ERR"
    area_val = "ERR"
    
    # パターンマッチ
    ret, match_point = ipc.func_pattern_match(ret,src_img,temp_img)
    
    # ソース画像の基準点補正
    reference_position_x = int(match_point[0]) + parameter.offset_src_x
    reference_position_y = int(match_point[1]) + parameter.offset_src_y
    
    # 着目画像切り出し
    ret,roi_img = ipc.func_createRoiimg(ret,src_img,reference_position_x,reference_position_y,parameter.offset_src_width,parameter.offset_src_height) 
    
    # グレースケール化
    ret,gray_img = ipc.func_grayscale(ret,roi_img)
    
    # エッジ検出①
    ret,edge_img = ipc.func_filter_2d_img(ret,gray_img,np.array([[1,0,-1],[1,0,-1],[1,0,-1]],np.float32))
    
    # 2値化
    ret,bin_img = ipc.func_threshold(ret,edge_img,parameter.bin_thr,bin_max_val)
    
    # 膨張処理
    ret,dilate_img = ipc.func_dilate_filter(ret,bin_img,parameter.dilate_kernel)
    
    # 平滑化
    ret,med_img = ipc.func_median_filter(ret,dilate_img,parameter.median_kernel_size)
    
    # 収縮処理
    ret,erode_img = ipc.func_erode_filter(ret,med_img,parameter.erode_kernel)
    
    # エッジ検出②
    ret,edge_img2 = ipc.func_filter_2d_img(ret,erode_img,np.array([[-1,0,1],[-1,0,1],[-1,0,1]],np.float32))
    
    # 着目画像切り出し②
    ret,roi_img2 = ipc.func_createRoiimg(ret,edge_img2,parameter.offset_flex_x,parameter.offset_flex_y,parameter.offset_flex_width,parameter.offset_flex_height) 
   
    # 白画素の数カウント
    ret,frex_white_pix = ipc.func_countWhitePix(ret,roi_img2)
    
    # 判定
    if frex_white_pix > parameter.area_thr:
        # 点列取得
        # コネクタ
        ret,connector_point_x,connector_point_y = ipc.func_get_point(ret,edge_img2,parameter.offset_connector_x,parameter.offset_connector_y,parameter.offset_connector_width,parameter.offset_connector_height)
        # フレキ
        ret,flex_point_x,flex_point_y = ipc.func_get_point(ret,edge_img2,parameter.offset_flex_x,parameter.offset_flex_y,parameter.offset_flex_width,parameter.offset_flex_height)

        try :
            # 点列の平均値算出
            # コネクタ
            connector_x_avg = np.int(np.average(connector_point_x))
            connector_y_avg = np.int(np.average(connector_point_y))
            # フレキ
            flex_x_avg = np.int(np.average(flex_point_x))
            flex_y_avg = np.int(np.average(flex_point_y))
            
            # 最小自乗法による近似直線算出
            # コネクタ
            A1 = np.array([connector_point_y,np.ones(len(connector_point_y))])
            A1= A1.T
            a1,b1 = np.linalg.lstsq(A1,connector_point_x)[0]
            
            # フレキ
            A2 = np.array([flex_point_y,np.ones(len(flex_point_y))])
            A2= A2.T
            a2,b2 = np.linalg.lstsq(A2,flex_point_x)[0]
            
            # コネクタ-フレキ間距離算出
            distance = np.abs(connector_x_avg - flex_x_avg)
            value.append(distance)
            
            # コネクタ-フレキの角度計算
            tan_theta = (a1 - a2)/(1 + a1*a2)
            theta = abs(np.arctan(tan_theta) * (180/np.pi))
            value.append(theta)
            
            #####直線の描画#####
            cv2.line(roi_img,(np.int(a1 * parameter.offset_connector_y + b1),parameter.offset_connector_y),(np.int(a1 * (parameter.offset_connector_y + parameter.offset_connector_height) + b1),parameter.offset_connector_y + parameter.offset_connector_height),(0,0,255),2)
            cv2.line(roi_img,(np.int(a2 * parameter.offset_flex_y + b2),parameter.offset_flex_y),(np.int(a2 * (parameter.offset_flex_y + parameter.offset_flex_height)+ b2),parameter.offset_flex_y + parameter.offset_flex_height),(0,255,0),2)

        except:
            value = 0

    #判定
    if distance > parameter.distance_thr or theta > parameter.theta_thr or area_val < parameter.area_thr :
        #NG
        output = 1
    else :
        #OK
        output = 0

    return ret,value,output,edge_img2


#############
# Main
#############
  
if __name__ == "__main__":
    
    ret = 0
    output = 0
    str_output = "OK"
    parameter_file_name = "parameter.ini"
    
    # パラメータファイルクラスのインスタンス化
    parameter = parameter_class.Parameter()
    # パラメータファイルの読み出し
    ret = parameter.SetParameter(parameter_file_name)
    if ret != 0:
        print "Failure Set Parameter."
        
    # 画像ファイルの読み出し
    ret,grab_img = ipc.func_imgread(ret,parameter.debug_image_file_name)
    if ret != 0:
        print "Failure Read SRC Image."

    # テンプレート画像	
    ret,temp_img = ipc.func_imgread(ret,parameter.debug_temp_image_file_name)	
    if ret != 0:
        print "Failure Read Template Image."

        
    # 画像処理関数の呼出し
    ret,value,output,proc_img = func_image_proc_main_sequence(grab_img,temp_img,parameter)
    
    if ret != 0:
        print "Failure Image Processing."
        output = -1
    
    # 判定
    if output == 0:
        str_output = "OK"
    
    elif output == 1:
        str_output = "NG"
    
    elif output == -1:
        str_output = "ERR"
    
    # 画像表示
    cv2.putText(grab_img,"Value:" + str(value),(10,50),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.putText(grab_img,"Output:" + str_output,(10,90),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.imshow('grab_img',np.array(grab_img,np.uint8))
    cv2.imshow('proc_img',np.array(proc_img,np.uint8))
    
    # 画像表示待機待ち
    cv2.waitKey(0)
    
    cv2.destroyAllWindows()