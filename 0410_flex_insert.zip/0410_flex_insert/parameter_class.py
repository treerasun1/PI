﻿# -*- coding: utf-8 -*-

"""
module :parameter_class.py
CRAVIS-miniで設定するパラメータを一覧にしたクラスになります。
CRAVIS-miniに新しいパラメータを追加したい時に編集します。
[SystemParam]はファイルパスや各種機器のパラメータ
[ImageProcParam]は画像処理パラメータになります。
①に追加したいパラメータを記述し、
②に追加パラメータをiniファイルから読み出す内容を記述します。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import ConfigParser

class Parameter(object):
    """description of class"""
    # [SystemParam]
    # ①↓システムのパラメータはこの下に追加する.
    flag_debug_mode = 0
    flag_save_image = 0
    flag_save_output_data = 0
    flag_disp_image = 0
    light_level = 0
    shutter_speed = 0
    mcp_ether_data_length = 0
    mcp_ether_data_address = 0
    ready_io_no = 0
    ok_io_no = 0
    ng_io_no = 0
    save_image_folder_name = ""
    debug_image_file_name = ""
    debug_temp_image_file_name = ""
    inspect_output_file_name = ""

    # [ImageProcParam]
    # ①↓画像処理のパラメータはこの下に追加する.
    offset_src_x = 0
    offset_src_y = 0
    offset_src_width = 0
    offset_src_height = 0
    offset_connector_x = 0
    offset_connector_y = 0
    offset_connector_width = 0
    offset_connector_height = 0
    offset_flex_x = 0
    offset_flex_y = 0
    offset_flex_width = 0
    offset_flex_height = 0
    bin_thr = 0
    area_thr = 0
    distance_thr = 0
    theta_thr = 0
    edge_kernel = 0
    erode_kernel = 0
    dilate_kernel =  0
    median_kernel_size = 0
    
    def __init__(self):
        print "Init Parameter"
    
    def SetParameter(self,file_name):
        
        """
        画像処理シーケンス関数
        _@param  self       インスタンス自身
        _@param  file_name  パラメータファイル名
        _@return ret        各関数の戻り値（正常終了時は0）
        """
        
        ret = 0
    
        try:
            inifile = ConfigParser.SafeConfigParser()
            inifile.read(file_name)
            # [SystemParam]
            # ②↓追加したパラメータはself.パラメータ名= int(inifile.get("SystemParam","パラメータ名"))の形で記述する.
            self.flag_save_image = int(inifile.get("SystemParam","flag_save_image"))
            self.flag_save_output_data = int(inifile.get("SystemParam","flag_save_output_data"))
            self.flag_disp_image = int(inifile.get("SystemParam","flag_disp_image"))
            self.light_level = int(inifile.get("SystemParam","light_level"))
            self.shutter_speed = int(inifile.get("SystemParam","shutter_speed"))
            self.mcp_ether_data_length = int(inifile.get("SystemParam","mcp_ether_data_length"))
            self.mcp_ether_data_address = int(inifile.get("SystemParam","mcp_ether_data_address"))
            self.ready_io_no = int(inifile.get("SystemParam","ready_io_no"))
            self.ok_io_no = int(inifile.get("SystemParam","ok_io_no"))
            self.ng_io_no = int(inifile.get("SystemParam","ng_io_no"))
            self.save_image_folder_name = inifile.get("SystemParam","save_image_folder_name")
            self.debug_image_file_name = inifile.get("SystemParam","debug_image_file_name")
            self.debug_temp_image_file_name = inifile.get("SystemParam","debug_temp_image_file_name")
            self.inspect_output_file_name = inifile.get("SystemParam","inspect_output_file_name")
            
            # [ImageProcParam]
            # ②↓追加したパラメータはself.パラメータ名= int(inifile.get("ImageProcParam","パラメータ名"))の形で記述する.
            self.offset_src_x = int(inifile.get("ImageProcParam","offset_src_x"))
            self.offset_src_y = int(inifile.get("ImageProcParam","offset_src_y"))
            self.offset_src_width = int(inifile.get("ImageProcParam","offset_src_width"))
            self.offset_src_height = int(inifile.get("ImageProcParam","offset_src_height"))
            self.offset_connector_x = int(inifile.get("ImageProcParam","offset_connector_x"))
            self.offset_connector_y = int(inifile.get("ImageProcParam","offset_connector_y"))
            self.offset_connector_width = int(inifile.get("ImageProcParam","offset_connector_width"))
            self.offset_connector_height = int(inifile.get("ImageProcParam","offset_connector_height"))
            self.offset_flex_x = int(inifile.get("ImageProcParam","offset_flex_x"))
            self.offset_flex_y = int(inifile.get("ImageProcParam","offset_flex_y"))
            self.offset_flex_width = int(inifile.get("ImageProcParam","offset_flex_width"))
            self.offset_flex_height = int(inifile.get("ImageProcParam","offset_flex_height"))
            self.bin_thr = int(inifile.get("ImageProcParam","bin_thr"))
            self.area_thr = int(inifile.get("ImageProcParam","area_thr"))
            self.distance_thr = int(inifile.get("ImageProcParam","distance_thr"))
            self.theta_thr = int(inifile.get("ImageProcParam","theta_thr"))
            self.erode_kernel = int(inifile.get("ImageProcParam","erode_kernel"))
            self.dilate_kernel = int(inifile.get("ImageProcParam","dilate_kernel"))
            self.median_kernel_size = int(inifile.get("ImageProcParam","median_kernel_size"))
            
        except:
            ret = -1
            print "Failure Set Parameter."
                
        finally:
            return ret
