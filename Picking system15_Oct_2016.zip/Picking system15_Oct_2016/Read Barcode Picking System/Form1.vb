﻿Imports System.IO.Ports

Public Class Form1
    Dim A As String
    'Dim areas As New List(Of 
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
       


    End Sub


    Private Sub btnconnectL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconnectL.Click
        Try
        
            If btnconnectL.Text = "Connect" Then
                SerialPort1.PortName = cmbport1.Text
                SerialPort1.Open()
                'Frmmain.Timer3.Enabled = True
                'My.Settings.cmbport1 = cmbport1.Text
                TextBox1.Focus()
                btnconnectL.BackColor = Color.Red
                btnconnectL.Text = "Disconnect"
                btnconnectL.ForeColor = Color.White
                Label1.Text = "Connect<" & SerialPort1.PortName.ToString & ">"
            ElseIf btnconnectL.Text = "Disconnect" Then
                btnconnectL.BackColor = Color.Green
                btnconnectL.Text = "Connect"
                SerialPort1.Close()
                Label1.Text = "Comport is Disconnect" & vbCr & "Please Reconnect"
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub readportsend()
        Dim strPortName() As String = SerialPort.GetPortNames()
        Dim n As String
        cmbport1.Items.Clear ()
        For Each n In strPortName
            cmbport1.Items.Add(n)
            '  cmbport1.Items.Add(n)
        Next
    End Sub

    Private Sub TextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        Try
            
            TextBox1.Focus()
            If e.KeyData = Keys.Enter Then
                '  If Len (TextBox1 .Text )= 15 then
                A = TextBox1.Text
                SerialPort1.WriteLine(A)

                ListBox1.Items.Add(A)
                '  Delay (1)
                A = ""
                TextBox1.Text = ""
                '  End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub cmbport1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbport1.Click
        readportsend ()
    End Sub
End Class
