# -*- coding: utf-8 -*- 
"""
module :image_proc_sequence.py
CRAVIS-miniの画像処理シーケンスモジュールになります。
image_proc_component.pyに記載されている画像処理関数群を
使用して、画像処理シーケンスを作成します。
単体で使用した場合、if __name__ == "__main__":以下のシーケンスが実行されます。
"""
__author__  = "CRAVIS-mini"
__version__ = "0.0.0.1"
__date__    = "20170407"

import cv2
import numpy as np
import csv
import math
import time
import sys
import image_proc_component as ipc
import parameter_class

#############
# Function
#############

def func_image_proc_main_sequence(src_img,parameter):
    """
    画像処理シーケンス関数
    @param  src_img    入力画像
    @param  parameter  パラメータ
    @return ret        各関数の戻り値（正常終了時は0）
    @return value      面積値[pix]
    @return output     結果(0：OK 1:NG)
    @return bin_img    2値画像    
    """
    ret = 0
    bin_max_val = 255
    serch_area_order = 1
    value = 0
    output = 0 # 0:OK 1:NG

    #着目画像切り出し
    ret,roi_img1 = ipc.func_createRoiimg(ret,src_img,parameter.roi_x1,parameter.roi_y1,parameter.roi_width1,parameter.roi_height1) 
    ret,roi_img2 = ipc.func_createRoiimg(ret,src_img,parameter.roi_x2,parameter.roi_y2,parameter.roi_width2,parameter.roi_height2)

   #グレースケール化
    ret,gray_img1 = ipc.func_grayscale(ret,roi_img1)
    ret,gray_img2 = ipc.func_grayscale(ret,roi_img2)

    #2値化
    ret,bin_img1 = ipc.func_threshold(ret,gray_img1,parameter.bin_thr,bin_max_val)
    ret,bin_img2 = ipc.func_threshold(ret,gray_img2,parameter.bin_thr,bin_max_val)
    
    #ラベリング
    ret,labels1,nb1 = ipc.func_labels(ret,bin_img1)
    ret,labels2,nb2 = ipc.func_labels(ret,bin_img2)
    
    #特徴量解析
    ret,areas1,centroid1 = ipc.func_calc_feature(ret,bin_img1,labels1)
    ret,areas2,centroid2 = ipc.func_calc_feature(ret,bin_img2,labels2)
    
    #任意ブロブ選択画像作成(1番大きいブロブのみ残す)
    ret,remove_img1 = ipc.func_blob_select(ret,areas1,serch_area_order,bin_max_val,labels1)
    ret,remove_img2 = ipc.func_blob_select(ret,areas2,serch_area_order,bin_max_val,labels2)
    
   #重心の計算
    imgEdge1,contours1,hierarchy1 = cv2.findContours(remove_img1,cv2.RETR_TREE,2)
    S1 = cv2.countNonZero(remove_img1)
    cnt1 = contours1[0]
    M1 = cv2.moments(cnt1)
    center_x1 = int(M1['m10']/M1['m00'])
    center_y1 = int(M1['m01']/M1['m00'])
    
    imgEdge2,contours2,hierarchy2 = cv2.findContours(remove_img2,cv2.RETR_TREE,2)
    S2 = cv2.countNonZero(remove_img2)
    cnt2 = contours2[0]
    M2 = cv2.moments(cnt2)
    center_x2 = int(M2['m10']/M2['m00'])
    center_y2 = int(M2['m01']/M2['m00'])
    
    #面積からの半径計算
    radius1 = np.sqrt((S1/3.14159))
    radius2 = np.sqrt((S2/3.14159))

    #楕円フィッティングの描写
    ellipse1 = cv2.fitEllipse(cnt1)
    ellipse2 = cv2.fitEllipse(cnt2)
    cv2.ellipse(roi_img1,ellipse1,(0,255,255),5)
    cv2.ellipse(roi_img2,ellipse2,(255,255,0),5)
    
    return ret,output,roi_img1,center_x1,center_y1,radius1,ellipse1,roi_img2,center_x2,center_y2,radius2,ellipse2

#############
# Main
#############

start_time = time.clock()

if __name__ == "__main__":

    ret = 0
    output = 0
    str_output = "OK"
    parameter_file_name = "parameter.ini"

    #パラメータファイルクラスのインスタンス化
    parameter = parameter_class.Parameter()
    #パラメータファイルの読み出し
    ret = parameter.SetParameter(parameter_file_name)
    if ret != 0:
        print "Failure Set Parameter."

    #画像ファイルの読み出し
    ret,grab_img = ipc.func_imgread(ret,parameter.debug_image_file_name)
    if ret != 0:
        print "Failure Read Image."

    #画像処理関数の呼出し
    ret,output,roi_img1,center_x1,center_y1,radius1,ellipse1,roi_img2,center_x2,center_y2,radius2,ellipse2 = func_image_proc_main_sequence(grab_img,parameter)
    if ret != 0:
        print "Failure Image Processing."
        output = -1

    #判定
    if output == 0:        
        str_output = "OK"

    elif output == 1:
        str_output = "NG"

    elif output == -1:
        str_output = "ERR"
        
    #結果表示
    print "左の円"
    print "center_x = " + str(parameter.roi_x1 + center_x1)
    print "center_y = " + str(parameter.roi_y1 + center_y1)
    print "radius = " + str(radius1 * parameter.resolution) + "[mm]"
    
    print "右の円"
    print "center_x = " + str(parameter.roi_x2 + center_x2)
    print "center_y = " + str(parameter.roi_y2 + center_y2)
    print "radius = " + str(radius2 * parameter.resolution) + "[mm]"

    #中心点描画
    cv2.circle(grab_img,(int(parameter.roi_x1 + center_x1),int(parameter.roi_y1 + center_y1)), 5, (0,0,255), -1)
    cv2.circle(grab_img,(int(parameter.roi_x2 + center_x2),int(parameter.roi_y2 + center_y2)), 5, (0,0,255), -1)
    #近似円描画
    cv2.circle(grab_img,(int(parameter.roi_x1 + center_x1),int(parameter.roi_y1 + center_y1)), int(radius1), (0,0,255), 3)
    cv2.circle(grab_img,(int(parameter.roi_x2 + center_x2),int(parameter.roi_y2 + center_y2)), int(radius2), (0,0,255), 3)

    #Resize
    resize_grab_img = cv2.resize(grab_img,(grab_img.shape[1]/parameter.diminution_rate,grab_img.shape[0]/parameter.diminution_rate))
    
    finish_time = time.clock()
    print "検査時間：" + str((finish_time - start_time)*1000) + "[msec]"
    
    #画像表示
    cv2.imshow('resize_grab_img',np.array(resize_grab_img,np.uint8))
    
    #画像表示待機待ち
    cv2.waitKey(0)

    #画像画面閉じる
    cv2.destroyAllWindows()

