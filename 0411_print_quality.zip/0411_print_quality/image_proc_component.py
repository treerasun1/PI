﻿# -*- coding: utf-8 -*-
"""
module :image_proc_component.py
CRAVIS-miniの画像処理コンポーネントモジュールになります。
image_proc_sequence.pyで呼出しを行います。
OpenCVの関数に例外処理をラッピングして関数化しています。
"""
__author__  = "CRAVIS-mini"
__version__ = "0.0.0.1"
__date__    = "20170407"

import cv2
import numpy as np
import math
from scipy import ndimage
from scipy import optimize
import scipy
import warnings

#############
# Function
#############
def func_imgread(ret,file_name):
    """
    画像読み込み関数
    @param  ret        関数戻り値
    @param  file_name  画像ファイル名
    @return ret        関数戻り値
    @return src_img    画像
    """
    if ret != 0:
        return ret,0

    try:
        src_img = cv2.imread(file_name)
    except:
        ret = 10101
        return ret,0

    return ret,src_img

def func_createRoiimg(ret,src_img,roi_x,roi_y,roi_width,roi_height):
    """
    ROI画像生成
    @param  ret        関数戻り値
    @param  src_img    元画像
    @param  roi_x      roi画像の始点ｘ座標
    @param  roi_y      roi画像の始点y座標
    @param  roi_width  roi画像の幅
    @param  roi_height roi画像の高さ
    @return ret        関数戻り値
    @return roi_img    roi画像  
    """    
    if ret != 0:
        return ret,0

    try:
        roi_img = src_img[roi_y : roi_y + roi_height , roi_x : roi_x + roi_width]
    except:
        ret = 10102
        return ret,0

    return ret,roi_img

def func_grayscale(ret,src_img):
    """
    ROI画像生成
    @param  ret        関数戻り値
    @param  src_img    元画像
    @return ret        関数戻り値
    @return gray_img   グレースケール画像
    """ 
    if ret != 0:
        return ret,0

    try:
        gray_img = cv2.cvtColor(src_img,cv2.COLOR_BGR2GRAY)
    except:
        ret = 10201
        return ret,0

    return ret,gray_img

def func_threshold(ret,src_img,threshold,maxval):
    """
    2値画像生成
    @param  ret        関数戻り値
    @param  src_img    元画像
    @param  threshold  2値化閾値
    @param  maxval     2値最大値
    @return ret        関数戻り値
    @return roi_img    2値画像
    """ 
    if ret != 0:
        return ret,0

    try:
        threshold_img = cv2.threshold(src_img,threshold,maxval,cv2.THRESH_BINARY)[1]
    except:
        ret = 10202
        return ret,0

    return ret,threshold_img

def func_blur_filter(ret,src_img,blur_kernel_size):
    """
    平滑化画像生成
    @param  ret               関数戻り値
    @param  src_img           元画像
    @param  blur_kernel_size  平滑化カーネルサイズ
    @return ret               関数戻り値
    @return blur_img          平滑化画像
    """ 
    if ret != 0:
        return ret,0

    try:
        blur_img = cv2.blur(src_img,blur_kernel_size)
    except:
        ret = 10203
        return ret,0

    return ret,blur_img

def func_gaussian_blur_filter(ret,src_img,gaussian_kernel_size,sigmaX):
    """
    ガウシアン平滑化画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  gaussian_kernel_size  平滑化カーネルサイズ
    @param  sigmaX                偏差
    @return ret                   関数戻り値
    @return gaussianblur_img      ガウシアン平滑化画像
    """ 
    if ret != 0:
        return ret,0

    try:
        gaussianblur_img = cv2.GaussianBlur(src_img,gaussian_kernel_size,sigmaX)
    except:
        ret = 10204
        return ret,0

    return ret,gaussianblur_img
    
def func_bilateral_filter(ret,src_img,bilateral_d,bilateral_sigmaColor,bilateral_sigmaSpace):
    """
    バイラテラルフィルタ平滑化画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  bilateral_d           フィルタリングで利用される，各ピクセル近傍領域の直径
    @param  bilateral_sigmaColor  色空間におけるフィルタシグマ
    @param  bilateral_sigmaSpace  座標空間におけるフィルタシグマ
    @return ret                   関数戻り値
    @return gaussianblur_img      バイラテラル画像
    """     
    if ret != 0:
        return ret,0
    try:
        bilateral_img = cv2.bilateralFilter(src_img,bilateral_d,bilateral_sigmaColor,bilateral_sigmaSpace)
    except:
        ret = 10205
        return ret,0

    return ret,bilateral_img
    
def func_median_filter(ret,src_img,median_kernel_size):
    """
    メディアンフィルタ画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  median_kernel_size    平滑化カーネルサイズ
    @return ret                   関数戻り値
    @return median_img            メディアンフィルタ画像
    """ 
    if ret != 0:
        return ret,0
    try:
        median_img = cv2.medianBlur(src_img,median_kernel_size)
    except:
        ret = 10206
        return ret,0

    return ret,median_img

def func_sobel_filter(ret,src_img,sobel_ddepth,sobel_dx,sobel_dy):
    """
    ソーベルフィルタ画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  sobel_ddepth          出力画像のビット深度
    @param  sobel_dx              xに関する微分の次数
    @param  sobel_dy              yに関する微分の次数
    @return ret                   関数戻り値
    @return sobel_img            　ソーベルフィルタ画像
    """ 
    
    if ret != 0:
        return ret,0
    try:
        sobel_img = cv2.Sobel(src_img,sobel_ddepth,sobel_dx,sobel_dy)
    except:
        ret = 10207
        return ret,0

    return ret,sobel_img

def func_laplacian_filter(ret,src_img,laplacian_ddepth):
    """
    ラプラシアン画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  laplacian_ddepth      出力画像のビット深度
    @return ret                   関数戻り値
    @return lap_img               ラプラシアンフィルタ画像
    *このフィルタは４近傍で計算されます
    """ 
    if ret != 0:
        return ret,0
    try:
        lap_img = cv2.Laplacian(src_img,laplacian_ddepth)
    except:
        ret = 10208
        return ret,0

    return ret,lap_img

def func_dilate_filter(ret,src_img,dilate_kernel):
    """
    膨張画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  dilate_kernel         膨張フィルターカーネルサイズ
    @return ret                   関数戻り値
    @return dilate_img            膨張画像
    """ 
    if ret != 0:
        return ret,0
    try:
        kernel = np.ones((dilate_kernel, dilate_kernel))
        dilate_img = cv2.dilate(src_img,kernel)
    except:
        ret = 10209
        return ret,0

    return ret,dilate_img

def func_erode_filter(ret,src_img,erode_kernel):
    """
    収縮画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  erode_kernel          収縮フィルターカーネルサイズ
    @return ret                   関数戻り値
    @return erode_img             収縮画像
    """     
    if ret != 0:
        return ret,0
    try:
        kernel = np.ones((erode_kernel, erode_kernel))
        erode_img = cv2.erode(src_img,kernel)
    except:
        ret = 10210
        return ret,0

    return ret,erode_img

def func_filter_2d_img(ret,src_img,kernel):
    """
    任意フィルター画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  kernel                任意フィルターカーネル
    @return filter_2d_img         任意フィルター画像
    """     
    if ret != 0:
        return ret,0

    try:
        filter_2d_img = cv2.filter2D(src_img,-1,kernel)
    except:
        ret = 10211
        return ret,0

    return ret,filter_2d_img
    
def func_RedColor_img(ret,src_img):
    """
    赤成分抽出画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return red_img               グレー画像（赤成分）
    """     
    if ret != 0:
        return ret,0
    try:
        red_img = src_img[:,:,2]
    except:
        ret = 10212
        return ret,0

    return ret,red_img

def func_GreenColor_img(ret,src_img):
    """
    緑成分抽出画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return green_img             グレー画像（緑成分）
    """       
    if ret != 0:
        return ret,0
    try:
        green_img = src_img[:,:,0]
    except:
        ret = 10213
        return ret,0

    return ret,green_img

def func_BlueColor_img(ret,src_img):
    """
    青成分抽出画像生成
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return blue_img              グレー画像（青成分）
    """     
    if ret != 0:
        return ret,0
    try:
        blue_img = src_img[:,:,1]
    except:
        ret = 10214
        return ret,0

    return ret,blue_img

def func_rgb_to_lab(ret,src_img):
    """
    RGB→L*a*b*色空間変換
    @param  ret                   関数戻り値
    @param  src_img               元画像（RGB)
    @return ret                   関数戻り値
    @return lab_img               変換画像（L*a*b*）
    """    
    if ret != 0:
        return ret,0
        
    try:
        lab_img = cv2.cvtColor(src_img,cv2.COLOR_RGB2LAB)
    except:
        ret = 10215
        return ret,0
        
    return ret,lab_img

def func_labels(ret,src_img):
    """
    ラベリング処理
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return labels                ラベル画像
    @return nb                    ラベル個数
    """ 
    if ret != 0:
        return ret,0,0

    try:
        labels , nb = ndimage.label(src_img)
    except:
        ret = 10216
        return ret,0,0

    return ret,labels,nb

def func_calc_feature(ret,bin_img,labels):
    """
    特徴量解析
    @param  ret                   関数戻り値
    @param  bin_img               2値画像
    @param  labels                ラベル画像
    @return ret                   関数戻り値
    @return areas                 面積
    @return centoroid　　　　　　　　　　重心
    """ 
    warnings.filterwarnings('ignore')
    
    if ret != 0:
        return ret,0,0
    
    try:
        #area
        areas = np.array(ndimage.sum(bin_img / bin_img.max(),labels,xrange(1,labels.max() + 1)))
        #centroid
        centroid = np.array(ndimage.center_of_mass(bin_img / bin_img.max(),labels,xrange(1,labels.max() + 1)))

    except:
        ret = 10217
        return ret,0,0

    return ret,areas,centroid

def func_blob_select(ret,areas,serch_area_order,bin_maxval,labels):
    """
    設定した任意のラベル番号のブロブのみ残した画像の作成
    @param  ret                   関数戻り値
    @param  areas                 面積のリスト
    @param  serch_area_order      探索する面積の大きさ番号（一番大きい面積のブロブを1として以下昇順）
    @param  bin_maxval            2値最大値
    @param  labels                ラベル画像
    @return ret                   関数戻り値
    @remove_img                   任意ラベルのみ画像
    """ 
    if ret != 0:
        return ret,0

    try:
        # CreateLabelIndexList
        label_index_list = [x for x in range(1,areas.size + 1)]
        # Marge LabelIndex And AreasList #
        list = [[label_index_list[i],areas[i]] for i in range(0,areas.size)]
        # Sort #
        sort_list = sorted(list,key=lambda i: i[1]) 
        # SerchSelectIndex #
        serch_index = sort_list[areas.size - serch_area_order][0]
        # CreateRemobeImg #
        remove_img = labels == serch_index
        remove_img = bin_maxval * remove_img
        remove_img = np.array(remove_img,np.uint8)

    except:
        ret = 10218
        return ret,0

    return ret,remove_img
    
def func_match_shapes(ret,ob1,ob2,method=1):
    """
    形状マッチング処理
    @param  ret                   関数戻り値
    @param  ob1                   元オブジェクト1(画像も可)
    @param  ob2                   元オブジェクト2(画像も可)
    @param  method                マッチング方法(1or2or3)
    @return ret                   関数戻り値
    @return sum(s)                形状マッチング評価値(0に近い方が、２つのオブジェクトの類似度が高い)
    """ 
    if ret != 0:
        return ret,0

    try:
        ma = cv2.moments(ob1)
        hua = cv2.HuMoments(ma)

        mb = cv2.moments(ob2)
        hub = cv2.HuMoments(mb)

        s = []

        if method == 1:
            for i in range(0,7):
                s.append(abs(1/math.copysign(math.log(abs(hua[i])),hua[i])-1/math.copysign(math.log(abs(hub[i])),hub[i])))
            return ret,sum(s)

        if method == 2:
            for i in range(0,7):
                s.append(abs(math.copysign(math.log(abs(hua[i])),hua[i])-math.copysign(math.log(abs(hub[i])),hub[i])))
            return ret,sum(s)

        if method == 3:
            for i in range(0,7):
                s.append(abs((math.copysign(math.log(abs(hua[i])),hua[i])-math.copysign(math.log(abs(hub[i])),hub
                             [i]))/math.copysign(math.log(abs(hua[i])),hua[i])))
            return ret,sum(s)
    except:
        ret = 10219
        return ret,0

def func_pattern_match(ret,src_img,template_img):
    """
    パターンマッチング処理
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  template_img          テンプレート画像
    @return ret                   関数戻り値
    @return match_point           マッチングした始点（x,y）
    """ 
    if ret != 0:
        return ret,0

    try:
        score = cv2.matchTemplate(src_img,template_img,cv2.TM_SQDIFF)  #OpenCV2.4 method = cv2.cv.CV_TM_SQDIFF
        macth_score_info = cv2.minMaxLoc(score)
        match_point = macth_score_info[2]
    except:
        ret = 10220
        return ret,0

    return ret,match_point

def func_rotate_img(ret,src_img,src_w,src_h,angle):
    """
    画像の回転変換
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @param  src_w                 元画像幅
    @param  src_h                 元画像高さ
    @param  angle                 回転角度
    @return ret                   関数戻り値
    @return rotate_img            回転画像
    """ 
    if ret != 0:
        return ret,0

    try:
        M = cv2.getRotationMatrix2D((src_w/2,src_h/2),angle,1)
        rotate_img = cv2.warpAffine(src_img,M,(src_w,src_h))
    except:
        ret = 10221
        return ret,0

    return ret,rotate_img

def func_countWhitePix(ret,src_img):
    """
    白色画素数のカウント
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return count                 カウント数
    """ 
    if ret != 0:
        return ret,0

    try:
        count = cv2.countNonZero(src_img)
    except:
        ret = 10222
        return ret,0

    return ret,count

def func_check_img_light_average(ret,src_img):
    """
    画像の平均輝度計算
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return light_avg_value       平均輝度値
    """ 
    if ret != 0:
        return ret,0

    light_avg_value = 0

    try:
        light_avg_value = np.average(src_img)
    except:
        ret = 10223
        return ret,0

    return ret,light_avg_value

def func_diff_img(ret,src_img1,src_img2):
    """
    画像間差分画像の生成
    @param  ret                   関数戻り値
    @param  src_img1              元画像1
    @param  src_img2              元画像2
    @return ret                   関数戻り値
    @return diff_img　　　　　　　　　　　差分画像（元画像1 - 元画像2）
    """
    if ret != 0:
        return ret,0
    try:
        diff_img = src_img1 - src_img2
    except:
        ret = 10224
        return ret,0

    return ret,diff_img

def func_polar2cart(ret,radius, theta, center):
    """
    極座標→直交座標変換
    @param  ret                   関数戻り値
    @param  radius                極座標r成分
    @param  theta                 極座標θ成分[radian]
    @param  center                極座標展開の中心座標(直交座標)
    @return ret                   関数戻り値
    @return x                     直交座標x成分
    @return y                     直交座標ｙ成分
    """
    if ret != 0:
        return ret,0,0

    try:
        x = radius * np.cos(theta) + center[0]
        y = radius * np.sin(theta) + center[1]

    except:
        ret = 10225
        return ret,0,0

    return ret,x,y


def func_cart2polar(ret,point_x,point_y,center):
    """
    直交座標→極座標変換
    @param  ret                   関数戻り値   　
    @param  point_x               直交座標x成分
    @param  point_y               直交座標ｙ成分
    @param  center                極座標展開の中心座標(直交座標)
    @return ret                   関数戻り値
    @return radius                極座標r成分
    @return theta                 極座標θ成分[radian]
    @return deg                   極座標θ成分[degree]
    """
    if ret != 0:
        return ret,0,0,0

    try:
        radius = np.sqrt((point_x - center[0])**2 + (point_y - center[1])**2)
        theta  = np.arctan2((point_y - center[1]) , (point_x - center[0]))
        deg    = theta * 180 / np.pi

        if center[1] > point_y:
            deg = deg + 360


    except:
        ret = 10226
        return ret,0,0,0

    return ret,radius,theta,deg

def func_img2polar(ret,src_img, center, pi, final_radius, initial_radius, phase_width):
    """
    極座標展開画像生成
    @param  ret                   関数戻り値
    @param　　ｓｒｃ_img               元画像
    @param  center                極座標展開の中心座標(直交座標)
    @param  pi                    展開する角度幅[degree]
    @param  final_radius          出力画像の高さ（下面）          
    @param  initial_radius        出力画像の高さ（上面）          
    @param  phase_width           出力画像の幅
    @return ret                   関数戻り値
    @return polar_img             極座標展開画像
    """
    if ret != 0:
        return ret,0

    try:
        x = np.linspace(0 , pi , phase_width)
        y = np.arange(initial_radius, final_radius)
    
        theta , R = np.meshgrid(x ,y)
    
        ret, Xcart, Ycart = func_polar2cart(ret, R, theta, center)

        Xcart = Xcart.astype(int)
        Ycart = Ycart.astype(int)

        if src_img.ndim == 3:
            polar_img = src_img[Ycart,Xcart,:]
            polar_img = np.reshape(polar_img,(final_radius-initial_radius,phase_width,3))
        else:
            polar_img = src_img[Ycart,Xcart]
            polar_img = np.reshape(polar_img,(final_radius-initial_radius,phase_width))

    except:
        ret = 10227
        return ret,0

    return ret,polar_img

def fit_func(parameter,x,y):

    A = parameter[0]
    B = parameter[1]
    C = parameter[2]

    redidual = (x - A) * (x - A) + (y - B) * (y - B) - C * C

    return redidual
    
def func_circle_fitting(ret,src_img,start_roi_x,start_roi_y,roi_width,roi_height):
    """
    最小二乗法による円近似
    @param  ret                   関数戻り値
    @param  ｓｒｃ_img               元画像
    @param  start_roi_x           roi画像の始点ｘ座標
    @param  start_roi_y           roi画像の始点ｙ座標
    @param  roi_width             roi画像の幅
    @param  roi_height            roi画像の高さ
    @return ret                   関数戻り値
    @return center_x              円中心ｘ座標
    @return center_y              円中心y座標
    @return radius                円半径
    """
    if ret != 0:
        return ret,0,0,0

    try:

        #SerchPoint
        index = np.where(src_img[start_roi_y : start_roi_y + roi_height , start_roi_x : start_roi_x + roi_width] > 0)
        x = index[1];
        y = index[0];

        #InitParam
        A0 = sum(x)/len(x)
        B0 = sum(y)/len(y)
        C0 = max(x) - sum(x)/len(x)
    
        init_parameter = [A0,B0,C0]
        
        result = scipy.optimize.leastsq(fit_func,init_parameter,args=(x,y))
        center_x = result[0][0]
        center_y = result[0][1]
        radius   = result[0][2]


    except:
        ret = 10228
        return ret,0,0,0

    return ret,center_x, center_y, radius
    
def func_draw_ellipse(ret,src_img,center,axes,angle,start_angle,end_angle,color,thickness,line_type):
    """
    部分楕円描画用の関数
    @param  ret                   関数戻り値
    @param　　ｓｒｃ_img               元画像
    @param  center                楕円中心
    @param  axes                  楕円の長径と短径
    @param  angle                 楕円の回転角度[degree]
    @param  start_angle           円弧の開始角度[degree]
    @param  end_angle             円弧の終了角度[degree]
    @param  color                 楕円の色
    @param  thickness             楕円の枠線の太さ
    @param  line_type             楕円の枠線の種類
    @return ret                   関数戻り値
    @return proc_img              楕円描画済みの画像
    """
    if ret != 0:
        return ret

    try:
        cv2.ellipse(src_img,center,axes,angle,start_angle,end_angle,color,thickness,line_type)
    except:
        ret = 10229
        return ret

    return ret

def func_bitwise_and(ret,src_img1,src_img2):
    """
    各要素のビット毎の論理積の計算
    @param  ret                   関数戻り値
    @param  src_img1              元画像1
    @param  src_img2              元画像2
    @param  output_array          出力配列（画像も可）
    @return ret                   関数戻り値
    @return proc_img　　　　　　　　　　　論理積画像
    """
    if ret != 0:
        return ret,0

    try:
        #proc_img = cv2.bitwise_and(src_img1,src_img2,mask = output_array)
        proc_img = cv2.bitwise_and(src_img1,src_img2)
    except:
        ret = 10230
        return ret,0

    return ret,proc_img

def func_bitwise_not(ret,src_img):
    """
    配列の各ビットを反転
    @param  ret                   関数戻り値
    @param  src_img               元画像
    @return ret                   関数戻り値
    @return proc_img              反転画像
    """
    if ret != 0:
        return ret,0

    try:
        proc_img = cv2.bitwise_not(src_img)
    except:
        ret = 10231
        return ret,0

    return ret,proc_img
