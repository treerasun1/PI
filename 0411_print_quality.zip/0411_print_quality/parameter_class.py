﻿# -*- coding: utf-8 -*- 
"""
module :parameter_class.py
CRAVIS-miniで設定するパラメータを一覧にしたクラスになります。
CRAVIS-miniに新しいパラメータを追加したい時に編集します。
[SystemParam]はファイルパスや各種機器のパラメータ
[ImageProcParam]は画像処理パラメータになります。
①に追加したいパラメータを記述し、
②に追加パラメータをiniファイルから読み出す内容を記述します。
"""
__author__  = "CRAVIS-mini"
__version__ = "0.0.0.1"
__date__    = "20170407"

import ConfigParser

class Parameter(object):
    """description of class"""
    #[SystemParam]
    #①↓システムのパラメータはこの下に追加する.
    flag_save_image = 0
    flag_save_output_data = 0
    flag_disp_image = 0
    light_level = 0
    shutter_speed = 0
    mcp_ether_data_length = 0
    mcp_ether_data_address = 0
    ready_io_no = 0
    ok_io_no = 0
    ng_io_no = 0
    save_image_folder_name = ""
    debug_image_file_name = ""
    inspect_output_file_name = ""
    #[ImageProcParam]
    #①↓画像処理のパラメータはこの下に追加する.
    diminution_rate = 0
    bin_thr = 0
    upper_radius_thr = 0
    lower_radius_thr = 0
    resolution = 0
    hosei_right_x = 0
    hosei_right_y = 0
    resolution_right_radius = 0
    hosei_left_x = 0
    hosei_left_y = 0
    resolution_left_radius = 0
    roi_x1 = 0
    roi_y1 = 0
    roi_width1 = 0
    roi_height1 = 0
    roi_x2 = 0
    roi_y2 = 0
    roi_width2 = 0
    roi_height2 = 0
    def __init__(self):
        print "Init Parameter"

    def SetParameter(self,file_name):
        """
        画像処理シーケンス関数
        @param  self       インスタンス自身
        @param  file_name  パラメータファイル名 
        @return ret        各関数の戻り値（正常終了時は0）
        """
        ret = 0

        try:
            inifile = ConfigParser.SafeConfigParser() 
            inifile.read(file_name)
            #[SystemParam]            
            #②↓追加したパラメータはself.パラメータ名= int(inifile.get("SystemParam","パラメータ名"))の形で記述する.            
            self.flag_save_image = int(inifile.get("SystemParam","flag_save_image"))
            self.flag_save_output_data = int(inifile.get("SystemParam","flag_save_output_data"))
            self.flag_disp_image = int(inifile.get("SystemParam","flag_disp_image"))
            self.light_level = int(inifile.get("SystemParam","light_level"))
            self.shutter_speed = int(inifile.get("SystemParam","shutter_speed"))
            self.mcp_ether_data_length = int(inifile.get("SystemParam","mcp_ether_data_length"))
            self.mcp_ether_data_address = int(inifile.get("SystemParam","mcp_ether_data_address"))
            self.ready_io_no = int(inifile.get("SystemParam","ready_io_no"))
            self.ok_io_no = int(inifile.get("SystemParam","ok_io_no"))
            self.ng_io_no = int(inifile.get("SystemParam","ng_io_no"))
            self.save_image_folder_name = inifile.get("SystemParam","save_image_folder_name")
            self.debug_image_file_name = inifile.get("SystemParam","debug_image_file_name")
            self.inspect_output_file_name = inifile.get("SystemParam","inspect_output_file_name")
            #[ImageProcParam]            
            #②↓追加したパラメータはself.パラメータ名= int(inifile.get("ImageProcParam","パラメータ名"))の形で記述する.           
            self.diminution_rate = int(inifile.get("ImageProcParam","diminution_rate"))
            self.resolution = float(inifile.get("ImageProcParam","resolution")) 
            self.hosei_right_x = float(inifile.get("ImageProcParam","hosei_right_x"))
            self.hosei_right_y = float(inifile.get("ImageProcParam","hosei_right_y"))
            self.resolution_right_radius = float(inifile.get("ImageProcParam","resolution_right_radius"))
            self.hosei_left_x = float(inifile.get("ImageProcParam","hosei_left_x"))
            self.hosei_left_y = float(inifile.get("ImageProcParam","hosei_left_y"))
            self.resolution_left_radius = float(inifile.get("ImageProcParam","resolution_left_radius"))
            self.roi_x1 = int(inifile.get("ImageProcParam","roi_x1"))
            self.roi_y1 = int(inifile.get("ImageProcParam","roi_y1"))
            self.roi_width1 = int(inifile.get("ImageProcParam","roi_width1"))
            self.roi_height1 = int(inifile.get("ImageProcParam","roi_height1"))
            self.bin_thr = int(inifile.get("ImageProcParam","bin_thr"))
            self.upper_radius_thr = int(inifile.get("ImageProcParam","upper_radius_thr"))
            self.lower_radius_thr = int(inifile.get("ImageProcParam","lower_radius_thr"))
            self.roi_x2 = int(inifile.get("ImageProcParam","roi_x2"))
            self.roi_y2 = int(inifile.get("ImageProcParam","roi_y2"))
            self.roi_width2 = int(inifile.get("ImageProcParam","roi_width2"))
            self.roi_height2 = int(inifile.get("ImageProcParam","roi_height2"))
            

        except:
            ret = -1
            print "Failure Set Parameter."
        finally:
            return ret


