﻿														
# -*- coding: utf-8 -*-

"""
module :image_proc_sequence.py
CRAVIS-miniの画像処理シーケンスモジュールになります。
image_proc_component.pyに記載されている画像処理関数群を使用して、画像処理シーケンスを作成します。
単体で使用した場合、if __name__ == __main__":以下のシーケンスが実行されます。
"""

__author__ = "cravis-mini"
__version__ = "0.0.0.1"
__date__ = "20161001"

import cv2
import numpy as np
import csv
import math
import time
import sys
import image_proc_component as ipc
import parameter_class

#############
# Function
#############

def func_image_proc_main_sequence(src_img,parameter):

    """
    画像処理シーケンス関数
    _@param src_img. 入力画像
    _@param parameter. パラメータ
    _@return ret. 各関数の戻り値（正常終了時は0）
    _@return value. 面積値[pix]
    _@return output. 結果(0：OK 1:NG)
    _@return bin_img. 2値画像
    """

    ret = 0
    bin_max_val = 255
    value = []
    value1 = 0
    value2 = 0
    # 0:OK 1:NG
    output = 0
    output1 = 0
    output2 = 0

    # グレースケール化
    ret,gray_img = ipc.func_grayscale(ret,src_img)
    
    # 2値化
    ret,bin_img = ipc.func_threshold(ret,gray_img,parameter.bin_thr,bin_max_val)
    
    # 着目画像切り出し①
    ret,roi_img1 = ipc.func_createRoiimg(ret,bin_img,parameter.roi_x1,parameter.roi_y1,parameter.roi_width1,parameter.roi_height1)
    
    # 着目画像切り出し②
    ret,roi_img2 = ipc.func_createRoiimg(ret,bin_img,parameter.roi_x2,parameter.roi_y2,parameter.roi_width2,parameter.roi_height2)
    
    # 着目画像切り出し③
    ret,roi_img3 = ipc.func_createRoiimg(ret,bin_img,parameter.roi_x3,parameter.roi_y3,parameter.roi_width3,parameter.roi_height3)
    
    # 白画素の数カウント①
    ret,value1 = ipc.func_countWhitePix(ret,roi_img1)
    
    # 白画素の数カウント②
    ret,value2 = ipc.func_countWhitePix(ret,roi_img2)
    
    # 判定①
    if value1 > parameter.judge_thr_upper1 or value1 < parameter.judge_thr_lower1:
        # NG
        output1 = 1
    else:
        # OK														
        output1 = 0
        
    # 判定②
    if value2 > parameter.judge_thr_upper2 or value2 < parameter.judge_thr_lower2:
        # NG
        output2 = 1
    else:
        # OK
        output2 = 0
        
    # 総合判定
    if output1 == 1 or output1 == 1:
        # NG
        output = 1
    else:
        # OK
        output = 0
        
    # 結果の配列形成
    value.append(value1)
    value.append(value2)
    
    return ret,value,output,roi_img3
    
#############
# Main
#############
    
if __name__ == "__main__":
    
    ret = 0
    output = 0
    str_output = "OK"
    parameter_file_name = "parameter.ini"
    
    # パラメータファイルクラスのインスタンス化
    parameter = parameter_class.Parameter()
    
    # パラメータファイルの読み出し
    ret = parameter.SetParameter(parameter_file_name)
    if ret != 0:
        print "Failure Set Parameter."
        
    # 画像ファイルの読み出し
    ret,grab_img = ipc.func_imgread(ret,parameter.debug_image_file_name)
    if ret != 0:
        print "Failure Read Image."
        
    # 画像処理関数の呼出し
    ret,value,output,proc_img = func_image_proc_main_sequence(grab_img,parameter)
    if ret != 0:
        print "Failure Image Processing."
        output = -1
        
    # 判定
    if output == 0:
        str_output = "OK"
    elif output == 1:
        str_output = "NG"
    elif output == -1:
        str_output = "ERR"

    # 画像表示														
    cv2.putText(grab_img,"Value:" + str(value),(10,50),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.putText(grab_img,"Output:" + str_output,(10,90),cv2.FONT_HERSHEY_PLAIN,2,(0,0,255),2)
    cv2.imshow('grab_img',np.array(grab_img,np.uint8))
    cv2.imshow('proc_img',np.array(proc_img,np.uint8))
    # 画像表示待機待ち
    cv2.waitKey(0)

    cv2.destroyAllWindows()